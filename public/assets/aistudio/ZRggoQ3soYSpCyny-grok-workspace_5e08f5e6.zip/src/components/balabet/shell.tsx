import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { DEFAULT_CANDY, useArt } from "@/lib/balabet/art";
import { phaseLabel, useDispute } from "@/lib/balabet/store";
import { RoundDirector } from "./round-director";

const LINKS = [
  { to: "/", label: "Início" },
  { to: "/apostar", label: "Apostar" },
  { to: "/top", label: "TOP" },
  { to: "/como-jogar", label: "Como jogar" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const phase = useDispute((state) => state.phase);
  const roundIndex = useDispute((state) => state.roundIndex);
  const resetOpen = useDispute((state) => state.resetOpen);
  const requestReset = useDispute((state) => state.requestReset);
  const cancelReset = useDispute((state) => state.cancelReset);
  const confirmReset = useDispute((state) => state.confirmReset);
  const { candy } = useArt();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const pending = useDispute.persist.rehydrate();
    if (pending instanceof Promise) {
      void pending.then(() => setReady(true));
      return;
    }
    setReady(true);
  }, []);

  return (
    <div className="min-h-screen">
      <RoundDirector />
      <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-2">
          <Link to="/" className="mr-1 flex items-center gap-2">
            <img src={candy || DEFAULT_CANDY} alt="" className="size-9 rounded-full object-cover" />
            <span className="text-lg font-semibold tracking-tight">BalaBet</span>
          </Link>
          <nav className="flex flex-1 gap-1 overflow-x-auto" aria-label="Principal">
            {LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="nav-link"
                data-active={pathname === link.to}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <p className="hidden font-mono text-xs tracking-wide text-gold sm:block" aria-live="polite">
            {ready ? phaseLabel(phase, roundIndex) : "CARREGANDO"}
          </p>
          <button type="button" className="btn btn-danger" data-testid="reset-open" onClick={requestReset}>
            Resetar todos os dados
          </button>
        </div>
      </header>
      <div className="mx-auto w-full max-w-6xl px-4 py-6">{ready ? children : <p className="text-muted">Carregando a disputa…</p>}</div>
      {resetOpen ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center" role="presentation">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="reset-title"
            className="panel w-full max-w-md p-5"
          >
            <h2 id="reset-title" className="text-lg font-semibold">
              Apagar a disputa?
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              Todos os dados desta disputa serão apagados: jogadores, saldos, apostas, vitórias, derrotas,
              empates, ranking, histórico, gráfico e sorteios. As imagens personalizadas permanecem.
            </p>
            <div className="mt-5 flex flex-wrap justify-end gap-2">
              <button type="button" className="btn btn-ghost" onClick={cancelReset}>
                Cancelar
              </button>
              <button type="button" className="btn btn-danger" data-testid="reset-confirm" onClick={confirmReset}>
                Apagar disputa
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
