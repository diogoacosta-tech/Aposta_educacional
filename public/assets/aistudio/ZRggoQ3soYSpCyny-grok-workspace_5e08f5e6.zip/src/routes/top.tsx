import { createFileRoute } from "@tanstack/react-router";
import { RankingTable } from "@/components/balabet/stats-table";
import { useDispute } from "@/lib/balabet/store";

export const Route = createFileRoute("/top")({
  component: TopPage,
});

function TopPage() {
  const phase = useDispute((state) => state.phase);
  const final = phase === "final";
  return (
    <main className="space-y-4">
      <div>
        <p className="font-mono text-xs tracking-wide text-gold">CLASSIFICAÇÃO</p>
        <h1 className="text-3xl font-semibold tracking-tight">TOP</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          Ordenado pela porcentagem de sucesso. Quem tem a mesma porcentagem divide a posição — não há
          desempate por saldo, nome ou quantidade de vitórias.
        </p>
      </div>
      <RankingTable final={final} />
    </main>
  );
}
