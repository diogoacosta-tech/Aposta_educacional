import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <main className="space-y-8">
      <section className="panel overflow-hidden p-6 sm:p-10">
        <p className="font-mono text-xs tracking-[0.18em] text-gold">SIMULAÇÃO · BALAS VIRTUAIS</p>
        <h1 className="mt-3 max-w-xl text-4xl font-semibold tracking-tight sm:text-5xl">
          Três rodadas. Linhas independentes. Nenhum dinheiro real.
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted">
          A BalaBet é uma disputa fechada para até cinco pessoas. Cada uma entra com o próprio saldo de balas,
          escolhe SUBIR, CAIR ou AUTOMÁTICO e vê o gráfico se mover por 15 segundos. O último segmento da sua
          linha decide a rodada.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/apostar" className="btn btn-primary">
            Ir para as apostas
          </Link>
          <Link to="/como-jogar" className="btn btn-ghost">
            Como jogar
          </Link>
        </div>
      </section>
      <section className="grid gap-3 md:grid-cols-3">
        {[
          ["1", "Cadastro", "Nomes únicos e saldo inicial individual. A disputa só começa com pelo menos um jogador."],
          ["2", "Três rodadas", "Contagem de 3 segundos, gráfico por 15 e resultados juntos. A rodada seguinte só começa com um novo clique."],
          ["3", "Fechamento", "Depois da terceira rodada, o ranking final. Um reset apaga a disputa e volta ao cadastro."],
        ].map(([step, title, copy]) => (
          <article key={step} className="panel p-5">
            <p className="font-mono text-sm text-gold">{step}</p>
            <h2 className="mt-2 text-lg font-semibold">{title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{copy}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
