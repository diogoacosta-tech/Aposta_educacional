import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useArt } from "@/lib/balabet/art";

export const Route = createFileRoute("/como-jogar")({
  component: HowToPage,
});

const SECTIONS = [
  {
    title: "Cadastro e saldos",
    body: "O responsável adiciona até cinco jogadores, cada um com nome único e saldo inicial de pelo menos uma bala. Os saldos são independentes. Nomes vazios, repetidos (ignorando maiúsculas e espaços extras) e um sexto jogador são recusados. Depois que a disputa começa, a lista fica fechada até o reset.",
  },
  {
    title: "Aposta de cada jogador",
    body: "Antes de cada rodada, cada pessoa escolhe SUBIR, CAIR ou AUTOMÁTICO e informa um inteiro de balas, no mínimo 1 e no máximo o saldo disponível. A aposta da rodada anterior pode ser alterada. Ela não fica obrigatória.",
  },
  {
    title: "SUBIR, CAIR e AUTOMÁTICO",
    body: "SUBIR vence se o último segmento da própria linha sobe, perde se desce e empata se não há deslocamento. CAIR é o inverso. AUTOMÁTICO vence na subida, perde na descida e empata sem movimento. O modo automático não dá prêmio maior nem chance extra.",
  },
  {
    title: "Contagem e gráfico",
    body: "COMEÇAR RODADA trava as apostas e abre uma contagem de 3 segundos, medida pelo tempo decorrido. Em seguida o gráfico anda por 15 segundos, também pelo relógio, não pela quantidade de quadros. As linhas são retas, independentes e angulosas. O nome fica na legenda. Passar o cursor destaca uma linha sem mudar o cálculo.",
  },
  {
    title: "Último segmento",
    body: "No fim dos 15 segundos as linhas congelam. Qualquer subida, mesmo mínima, é alta. Qualquer queda, mesmo mínima, é baixa. Sem deslocamento, é empate. O resultado usa só o que está visível nesse instante. O gráfico é uma simulação aleatória e não promete o próximo movimento.",
  },
  {
    title: "Saldos",
    body: "Na vitória, a aposta volta e entra um prêmio adicional de 1 a 5 balas. O número anunciado é só o prêmio, não a devolução. Na derrota, perde-se apenas a quantidade apostada. No empate, a aposta volta e não há prêmio. O saldo não fica negativo e a mesma rodada não é liquidada duas vezes.",
  },
  {
    title: "Prêmio em balas",
    body: "Cada vitória sorteia o prêmio com os pesos 28, 28, 22, 11 e 6 (soma 95), para 1, 2, 3, 4 e 5 balas. O sorteio não depende da altura da linha, do modo nem do valor apostado.",
  },
  {
    title: "Pirulito raro",
    body: "É um brinde, não uma moeda. Não se aposta, não se compra e não substitui as balas. Só pode sair numa vitória, com 5% de chance independente do prêmio em balas. Derrota e empate nunca dão pirulito. Quando sai, a vitória continua visível junto com a animação do brinde.",
  },
  {
    title: "Quadrinhos, SAIR e a rodada seguinte",
    body: "No fim da rodada, todos os quadrinhos aparecem ao mesmo tempo e permanecem até SAIR. SAIR depois da primeira ou da segunda rodada fecha o painel, devolve o gráfico à posição inicial e libera as apostas. A rodada seguinte não começa sozinha: é preciso clicar de novo em COMEÇAR RODADA. Depois da terceira, SAIR abre o ranking final e impede uma quarta rodada. O gráfico dessa última rodada fica congelado.",
  },
  {
    title: "Estatísticas, TOP e reset",
    body: "A porcentagem de sucesso é vitórias ÷ (vitórias + derrotas) × 100. Empate não entra. Sem vitória e sem derrota, aparece um traço. O TOP usa os mesmos números e não desempatam porcentagens iguais. RESETAR TODOS OS DADOS pede confirmação em qualquer fase. Cancelar preserva tudo. Confirmar apaga a disputa e volta ao cadastro, sem apagar as imagens personalizadas.",
  },
];

function HowToPage() {
  const art = useArt();
  const [message, setMessage] = useState<string | null>(null);
  return (
    <main className="space-y-5">
      <header>
        <p className="font-mono text-xs tracking-wide text-gold">REGRAS</p>
        <h1 className="text-3xl font-semibold tracking-tight">Como jogar</h1>
      </header>
      <div className="grid gap-3">
        {SECTIONS.map((section) => (
          <section key={section.title} className="panel p-5">
            <h2 className="text-lg font-semibold">{section.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{section.body}</p>
          </section>
        ))}
      </div>
      <section className="panel overflow-x-auto p-5">
        <h2 className="text-lg font-semibold">Tabela do prêmio adicional</h2>
        <table className="mt-3 w-full min-w-[20rem] text-left text-sm">
          <thead className="text-muted">
            <tr>
              <th className="py-2 font-medium">Prêmio</th>
              <th className="py-2 font-medium">Peso</th>
              <th className="py-2 font-medium">Chance</th>
            </tr>
          </thead>
          <tbody>
            {[
              ["1 bala", "28", "29,47%"],
              ["2 balas", "28", "29,47%"],
              ["3 balas", "22", "23,16%"],
              ["4 balas", "11", "11,58%"],
              ["5 balas", "6", "6,32%"],
            ].map((row) => (
              <tr key={row[0]} className="border-t border-line">
                {row.map((cell) => (
                  <td key={cell} className="py-2 font-mono">
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-3 text-sm text-muted">
          Exemplo de conta, não um resultado ao vivo: saldo 2, aposta 1, prêmio 3, saldo final 5. A aposta
          volta e as 3 balas são o prêmio.
        </p>
      </section>
      <section className="panel border-gold/40 p-5">
        <h2 className="text-lg font-semibold">Aviso</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          A BalaBet usa somente balas virtuais, sem valor monetário, depósito ou saque. Apostar dinheiro real
          pode causar perdas financeiras e problemas pessoais ou familiares. Divirta-se com consciência. Não
          aposte dinheiro das necessidades essenciais e não tente recuperar perdas.
        </p>
      </section>
      <section className="panel p-5">
        <h2 className="text-lg font-semibold">Aparência da bala e do pirulito</h2>
        <p className="mt-2 text-sm text-muted">A troca muda só a imagem. Não altera saldo, chance ou regra.</p>
        <div className="mt-4 flex flex-wrap items-center gap-4">
          <img src={art.candy} alt="Bala virtual" className="size-16 rounded-full object-cover" />
          <img src={art.lollipop} alt="Pirulito raro" className="size-16 rounded-full object-cover" />
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="text-sm">
            Imagem da bala
            <input
              className="field mt-1"
              type="file"
              accept="image/*"
              onChange={async (event) => {
                const file = event.target.files?.[0] ?? null;
                setMessage(await art.setFile("candy", file));
              }}
            />
          </label>
          <label className="text-sm">
            Imagem do pirulito
            <input
              className="field mt-1"
              type="file"
              accept="image/*"
              onChange={async (event) => {
                const file = event.target.files?.[0] ?? null;
                setMessage(await art.setFile("lollipop", file));
              }}
            />
          </label>
        </div>
        {message ? <p className="mt-2 text-sm text-loss">{message}</p> : null}
        <button type="button" className="btn btn-ghost mt-3" onClick={() => art.resetArt()}>
          Restaurar imagens originais
        </button>
      </section>
    </main>
  );
}
