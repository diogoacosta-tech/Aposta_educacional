import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChartPanel } from "@/components/balabet/chart-panel";
import { ResultsPanel } from "@/components/balabet/results-panel";
import { StatsTable, RankingTable } from "@/components/balabet/stats-table";
import {
  COUNTDOWN_MS,
  MODE_LABEL,
  ROUND_MS,
  formatBalas,
  stakeError,
  type Mode,
} from "@/lib/balabet/engine";
import { useLive } from "@/lib/balabet/live";
import { phaseLabel, useDispute } from "@/lib/balabet/store";

export const Route = createFileRoute("/apostar")({
  component: ApostarPage,
});

const MODES: Mode[] = ["subir", "cair", "automatico"];

function colorOf(index: number) {
  return `var(--color-player-${index + 1})`;
}

function ApostarPage() {
  const phase = useDispute((state) => state.phase);
  const players = useDispute((state) => state.players);
  const roundIndex = useDispute((state) => state.roundIndex);
  const drafts = useDispute((state) => state.drafts);
  const locked = useDispute((state) => state.locked);
  const lockedBets = useDispute((state) => state.lockedBets);
  const banner = useDispute((state) => state.banner);
  const addPlayer = useDispute((state) => state.addPlayer);
  const removePlayer = useDispute((state) => state.removePlayer);
  const beginDispute = useDispute((state) => state.beginDispute);
  const setDraft = useDispute((state) => state.setDraft);
  const startRound = useDispute((state) => state.startRound);
  const [name, setName] = useState("");
  const [balance, setBalance] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const clock = useLive((state) => state.clockMs);

  const countdown = phase === "countdown" ? Math.max(1, 3 - Math.floor(clock / 1000)) : null;
  const runningLeft =
    phase === "running" ? Math.max(0, ROUND_MS - Math.max(0, clock - COUNTDOWN_MS)) / 1000 : null;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-wide text-gold">{phaseLabel(phase, roundIndex)}</p>
          <h1 className="text-3xl font-semibold tracking-tight">Apostar</h1>
        </div>
        {runningLeft !== null ? (
          <p className="font-mono text-2xl text-fg" aria-live="polite">
            {runningLeft.toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 })}s
          </p>
        ) : null}
      </div>

      {banner ? (
        <p role="alert" className="rounded-xl border border-loss/40 bg-surface px-4 py-3 text-sm text-loss">
          {banner}
        </p>
      ) : null}

      {phase === "registration" ? (
        <section className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
          <form
            className="panel space-y-4 p-5"
            onSubmit={(event) => {
              event.preventDefault();
              const error = addPlayer(name, balance);
              if (error) {
                setFormError(error);
                return;
              }
              setFormError(null);
              setName("");
              setBalance("");
            }}
          >
            <h2 className="text-lg font-semibold">Cadastro</h2>
            <p className="text-sm leading-relaxed text-muted">
              Até cinco jogadores, cada um com o próprio saldo em balas virtuais. Depois que a disputa começa,
              só um reset permite trocar a lista.
            </p>
            <label className="block text-sm">
              Nome
              <input
                className="field mt-1"
                value={name}
                onChange={(event) => setName(event.target.value)}
                maxLength={24}
                aria-invalid={Boolean(formError)}
              />
            </label>
            <label className="block text-sm">
              Saldo inicial
              <input
                className="field mt-1"
                inputMode="numeric"
                value={balance}
                onChange={(event) => setBalance(event.target.value)}
                placeholder="Inteiro, mínimo 1"
              />
            </label>
            {formError ? (
              <p role="alert" className="text-sm text-loss">
                {formError}
              </p>
            ) : null}
            <button type="submit" className="btn btn-primary" data-testid="add-player" disabled={players.length >= 5}>
              Adicionar jogador
            </button>
          </form>
          <div className="panel p-5">
            <h2 className="text-lg font-semibold">Jogadores</h2>
            {players.length === 0 ? (
              <p className="mt-3 text-sm text-muted">Ninguém cadastrado ainda.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {players.map((player) => (
                  <li key={player.id} className="flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2">
                    <span className="flex items-center gap-2">
                      <span className="size-2.5 rounded-full" style={{ background: colorOf(player.colorIndex) }} />
                      <span>{player.name}</span>
                      <span className="font-mono text-xs text-muted">{formatBalas(player.balance)} balas</span>
                    </span>
                    <button type="button" className="btn btn-ghost" onClick={() => removePlayer(player.id)}>
                      Remover
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <button
              type="button"
              className="btn btn-primary mt-4"
              data-testid="begin-dispute"
              onClick={() => {
                const error = beginDispute();
                setFormError(error);
              }}
            >
              Ir para as apostas
            </button>
          </div>
        </section>
      ) : (
        <>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {players.map((player) => {
              const draft = drafts[player.id] ?? { mode: "", amount: "" };
              const bet = lockedBets[player.id];
              const shownStake = locked && bet ? bet.stake : Number(draft.amount);
              const reserved =
                locked && bet ? Math.max(0, player.balance - bet.stake) : player.balance;
              const error =
                phase === "preparing"
                  ? player.balance < 1
                    ? "Sem balas para a aposta mínima de 1. A rodada não pode começar."
                    : !draft.mode
                      ? "Escolha o modo."
                      : stakeError(draft.amount, player.balance)
                  : null;
              return (
                <article key={player.id} className="panel p-4">
                  <header className="flex items-center justify-between gap-2">
                    <h2 className="flex items-center gap-2 font-semibold">
                      <span className="size-2.5 rounded-full" style={{ background: colorOf(player.colorIndex) }} />
                      {player.name}
                    </h2>
                    <span className="font-mono text-xs text-muted">
                      {locked && bet ? `Disponível ${formatBalas(reserved)}` : `Saldo ${formatBalas(player.balance)}`}
                    </span>
                  </header>
                  <div className="mt-3 grid grid-cols-3 gap-1" role="group" aria-label={`Modo de ${player.name}`}>
                    {MODES.map((mode) => {
                      const selected = (locked ? bet?.mode : draft.mode) === mode;
                      return (
                        <button
                          key={mode}
                          type="button"
                          disabled={locked || phase !== "preparing"}
                          aria-pressed={selected}
                          className={`btn ${selected ? "btn-primary" : "btn-ghost"} px-1 text-xs`}
                          onClick={() => setDraft(player.id, { mode })}
                        >
                          {MODE_LABEL[mode]}
                        </button>
                      );
                    })}
                  </div>
                  <label className="mt-3 block text-sm">
                    Balas nesta rodada
                    <input
                      className="field mt-1 font-mono"
                      inputMode="numeric"
                      disabled={locked || phase !== "preparing"}
                      value={locked && bet ? String(bet.stake) : draft.amount}
                      onChange={(event) => setDraft(player.id, { amount: event.target.value })}
                    />
                  </label>
                  {phase === "preparing" && error ? <p className="mt-2 text-xs text-loss">{error}</p> : null}
                  {locked && bet ? (
                    <p className="mt-2 text-xs text-muted">
                      Aposta bloqueada: {formatBalas(shownStake)} · {MODE_LABEL[bet.mode]}
                    </p>
                  ) : null}
                  {player.history.length > 0 ? (
                    <p className="mt-2 text-xs text-muted">
                      {player.history
                        .map((item) => {
                          const word = item.outcome === "win" ? "vitória" : item.outcome === "loss" ? "derrota" : "empate";
                          return `R${item.round} ${word}`;
                        })
                        .join(" · ")}
                    </p>
                  ) : null}
                </article>
              );
            })}
          </div>

          <div className="relative">
            <ChartPanel phase={phase} />
            {countdown !== null ? (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <p key={countdown} className="count-pop font-mono text-7xl font-semibold text-gold" aria-live="assertive">
                  {countdown}
                </p>
              </div>
            ) : null}
          </div>

          {phase === "running" && runningLeft !== null ? (
            <div className="h-1.5 overflow-hidden rounded-full bg-surface-2" aria-hidden="true">
              <div
                className="h-full bg-gold"
                style={{ width: `${((ROUND_MS - runningLeft * 1000) / ROUND_MS) * 100}%` }}
              />
            </div>
          ) : null}

          {phase === "preparing" ? (
            <button
              type="button"
              className="btn btn-primary"
              data-testid="start-round"
              disabled={players.some((player) => {
                const draft = drafts[player.id];
                return (
                  player.balance < 1 ||
                  !draft ||
                  !draft.mode ||
                  stakeError(draft.amount, player.balance) !== null
                );
              })}
              onClick={() => startRound()}
            >
              COMEÇAR RODADA
            </button>
          ) : null}
          {phase === "final" ? (
            <div className="space-y-3">
              <p className="text-sm text-muted">
                As três rodadas acabaram. O gráfico permanece no estado final e não existe quarta rodada.
              </p>
              <RankingTable final />
            </div>
          ) : null}
          <StatsTable />
        </>
      )}
      <ResultsPanel />
    </div>
  );
}
