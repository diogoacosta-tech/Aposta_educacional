import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/settle")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return Response.json(
            { ok: false, code: "validation", error: "JSON inválido." },
            { status: 400 },
          );
        }
        const { settleThroughSchoolStack } = await import("@/lib/balabet/school-bridge.server");
        const result = await settleThroughSchoolStack(body);
        return Response.json(result.json, { status: result.status });
      },
    },
  },
});
