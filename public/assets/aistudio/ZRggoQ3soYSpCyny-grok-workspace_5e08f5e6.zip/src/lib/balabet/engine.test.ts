import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { createLiveSimulator, mulberry32 } from "./chart.ts";
import {
  lollipopFromRoll,
  prizeFromRoll,
  rankPlayers,
  settle,
  successRatio,
  validateNewPlayer,
} from "./engine.ts";

test("prêmios seguem os pesos 28, 28, 22, 11 e 6", () => {
  const counts = [0, 0, 0, 0, 0, 0];
  for (let roll = 0; roll < 95; roll++) counts[prizeFromRoll(roll)] += 1;
  assert.deepEqual(counts.slice(1), [28, 28, 22, 11, 6]);
  assert.equal(prizeFromRoll(56), 3);
});

test("pirulito só nos cinco primeiros valores de 100", () => {
  for (let roll = 0; roll < 100; roll++) {
    assert.equal(lollipopFromRoll(roll), roll < 5);
  }
});

test("exemplos de saldo da especificação", () => {
  const win = settle({
    balance: 2,
    stake: 1,
    mode: "subir",
    direction: "up",
    prizeRoll: 56,
    lollipopRoll: 0,
  });
  assert.equal(win.outcome, "win");
  assert.equal(win.prize, 3);
  assert.equal(win.balanceAfter, 5);
  assert.equal(win.displayedDelta, 3);
  assert.equal(win.lollipop, true);

  const loss = settle({
    balance: 10,
    stake: 1,
    mode: "subir",
    direction: "down",
    prizeRoll: 0,
    lollipopRoll: 0,
  });
  assert.equal(loss.balanceAfter, 9);
  assert.equal(loss.lollipop, false);

  const bust = settle({
    balance: 2,
    stake: 2,
    mode: "cair",
    direction: "up",
    prizeRoll: 0,
    lollipopRoll: 0,
  });
  assert.equal(bust.balanceAfter, 0);
  assert.equal(bust.prize, 0);

  const tie = settle({
    balance: 8,
    stake: 3,
    mode: "automatico",
    direction: "flat",
    prizeRoll: 0,
    lollipopRoll: 0,
  });
  assert.equal(tie.outcome, "tie");
  assert.equal(tie.balanceAfter, 8);
  assert.equal(tie.lollipop, false);
});

test("recusa aposta inválida e cadastro duplicado", () => {
  assert.throws(() =>
    settle({ balance: 3, stake: 4, mode: "subir", direction: "up", prizeRoll: 0, lollipopRoll: 50 }),
  );
  assert.equal(successRatio(0, 0), null);
  assert.equal(successRatio(1, 1), 50);
  assert.equal(successRatio(2, 0), 100);
  const duplicated = validateNewPlayer(" maria ", "10", ["Maria"], 1);
  assert.ok("error" in duplicated);
  const sixth = validateNewPlayer("Lia", "4", ["a", "b", "c", "d", "e"], 5);
  assert.ok("error" in sixth);
  const ok = validateNewPlayer("  João   Pedro ", "8", [], 0);
  assert.deepEqual(ok, { name: "João Pedro", balance: 8 });
  assert.ok("error" in validateNewPlayer("Ana", "0", [], 0));
  assert.ok("error" in validateNewPlayer("Ana", "1.5", [], 0));
});

test("ranking empata porcentagem igual e ignora empates no cálculo", () => {
  const ranked = rankPlayers([
    { id: "a", name: "Ana", wins: 1, losses: 1 },
    { id: "b", name: "Bia", wins: 2, losses: 2 },
    { id: "c", name: "Caio", wins: 1, losses: 0 },
    { id: "d", name: "Duda", wins: 0, losses: 0 },
  ]);
  assert.equal(ranked[0].id, "c");
  assert.equal(ranked[0].rank, 1);
  assert.equal(ranked[1].rank, 2);
  assert.equal(ranked[2].rank, 2);
  assert.equal(ranked[1].tied, true);
  assert.equal(ranked[2].tied, true);
  assert.equal(ranked[3].percent, null);
  assert.equal(ranked[1].wins === 1 || ranked[2].wins === 1, true);
});

test("o gráfico não revela ponto além do relógio e termina aos 15s", () => {
  const sim = createLiveSimulator(mulberry32(7), 50);
  let previous = 0;
  for (const mark of [0, 120, 1000, 8000, 15000]) {
    const points = sim.visible(mark);
    assert.ok(points.every((point) => point.t <= mark + 0.001));
    for (let index = 1; index < points.length; index++) {
      assert.ok(points[index].t >= points[index - 1].t);
    }
    const last = points[points.length - 1].t;
    assert.ok(last + 0.001 >= previous);
    previous = last;
  }
  const end = createLiveSimulator(mulberry32(7), 50).visible(15000);
  assert.equal(end[end.length - 1].t, 15000);
  assert.ok(end.length >= 2);
});

test("Java e PHP concordam com a tabela e com o exemplo de saldo", () => {
  const java = spawnSync("java", ["-cp", "school/java/build", "com.balabet.Main", "selftest"], {
    cwd: "/workspace",
    encoding: "utf8",
  });
  assert.equal(java.status, 0, java.stderr || java.stdout);
  assert.match(java.stdout, /PASS/);

  for (let roll = 0; roll < 95; roll++) {
    const mapped = spawnSync("java", ["-cp", "school/java/build", "com.balabet.Main", "map", String(roll)], {
      cwd: "/workspace",
      encoding: "utf8",
    });
    assert.equal(Number(mapped.stdout.trim()), prizeFromRoll(roll));
  }

  const payload = {
    players: [
      {
        id: "joao",
        balance: 2,
        stake: 1,
        mode: "subir",
        direction: "up",
        prizeRoll: 56,
        lollipopRoll: 0,
      },
      {
        id: "maria",
        balance: 10,
        stake: 1,
        mode: "cair",
        direction: "up",
        prizeRoll: 0,
        lollipopRoll: 0,
      },
    ],
  };
  const php = spawnSync("/workspace/school/bin/php", ["/workspace/school/php/settle.php"], {
    input: JSON.stringify(payload),
    encoding: "utf8",
  });
  assert.equal(php.status, 0, php.stderr || php.stdout);
  const body = JSON.parse(php.stdout) as {
    ok: boolean;
    via: string;
    engine: string;
    results: { id: string; outcome: string; prize: number; balanceAfter: number; lollipop: boolean }[];
  };
  assert.equal(body.ok, true);
  assert.equal(body.via, "php");
  assert.equal(body.engine, "java");
  assert.equal(body.results[0].balanceAfter, 5);
  assert.equal(body.results[0].prize, 3);
  assert.equal(body.results[0].lollipop, true);
  assert.equal(body.results[1].outcome, "loss");
  assert.equal(body.results[1].balanceAfter, 9);
  assert.equal(body.results[1].lollipop, false);
});
