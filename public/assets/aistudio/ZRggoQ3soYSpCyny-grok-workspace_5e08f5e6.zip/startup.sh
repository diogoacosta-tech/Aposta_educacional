#!/bin/sh
set -eu
cd /workspace
node scripts/preview.mjs stop || true
if [ ! -f /workspace/school/java/build/com/balabet/Main.class ]; then
  mkdir -p /workspace/school/java/build
  javac -encoding UTF-8 -d /workspace/school/java/build /workspace/school/java/src/com/balabet/*.java
fi
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  exit 0
fi
npm run dev >>/tmp/app-startup.log 2>&1 &
