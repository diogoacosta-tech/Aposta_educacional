import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-KIjWDHjp.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "panel overflow-hidden p-6 sm:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-[0.18em] text-gold",
					children: "SIMULAÇÃO · BALAS VIRTUAIS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 max-w-xl text-4xl font-semibold tracking-tight sm:text-5xl",
					children: "Três rodadas. Linhas independentes. Nenhum dinheiro real."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-base leading-relaxed text-muted",
					children: "A BalaBet é uma disputa fechada para até cinco pessoas. Cada uma entra com o próprio saldo de balas, escolhe SUBIR, CAIR ou AUTOMÁTICO e vê o gráfico se mover por 15 segundos. O último segmento da sua linha decide a rodada."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/apostar",
						className: "btn btn-primary",
						children: "Ir para as apostas"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/como-jogar",
						className: "btn btn-ghost",
						children: "Como jogar"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "grid gap-3 md:grid-cols-3",
			children: [
				[
					"1",
					"Cadastro",
					"Nomes únicos e saldo inicial individual. A disputa só começa com pelo menos um jogador."
				],
				[
					"2",
					"Três rodadas",
					"Contagem de 3 segundos, gráfico por 15 e resultados juntos. A rodada seguinte só começa com um novo clique."
				],
				[
					"3",
					"Fechamento",
					"Depois da terceira rodada, o ranking final. Um reset apaga a disputa e volta ao cadastro."
				]
			].map(([step, title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm text-gold",
						children: step
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-lg font-semibold",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: copy
					})
				]
			}, step))
		})]
	});
}
//#endregion
export { Home as component };
