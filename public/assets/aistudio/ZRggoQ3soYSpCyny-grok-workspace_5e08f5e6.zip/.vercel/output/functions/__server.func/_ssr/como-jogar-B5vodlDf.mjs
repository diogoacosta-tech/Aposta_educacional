import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as useArt } from "./router-1gb8mQX7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/como-jogar-B5vodlDf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SECTIONS = [
	{
		title: "Cadastro e saldos",
		body: "O responsável adiciona até cinco jogadores, cada um com nome único e saldo inicial de pelo menos uma bala. Os saldos são independentes. Nomes vazios, repetidos (ignorando maiúsculas e espaços extras) e um sexto jogador são recusados. Depois que a disputa começa, a lista fica fechada até o reset."
	},
	{
		title: "Aposta de cada jogador",
		body: "Antes de cada rodada, cada pessoa escolhe SUBIR, CAIR ou AUTOMÁTICO e informa um inteiro de balas, no mínimo 1 e no máximo o saldo disponível. A aposta da rodada anterior pode ser alterada. Ela não fica obrigatória."
	},
	{
		title: "SUBIR, CAIR e AUTOMÁTICO",
		body: "SUBIR vence se o último segmento da própria linha sobe, perde se desce e empata se não há deslocamento. CAIR é o inverso. AUTOMÁTICO vence na subida, perde na descida e empata sem movimento. O modo automático não dá prêmio maior nem chance extra."
	},
	{
		title: "Contagem e gráfico",
		body: "COMEÇAR RODADA trava as apostas e abre uma contagem de 3 segundos, medida pelo tempo decorrido. Em seguida o gráfico anda por 15 segundos, também pelo relógio, não pela quantidade de quadros. As linhas são retas, independentes e angulosas. O nome fica na legenda. Passar o cursor destaca uma linha sem mudar o cálculo."
	},
	{
		title: "Último segmento",
		body: "No fim dos 15 segundos as linhas congelam. Qualquer subida, mesmo mínima, é alta. Qualquer queda, mesmo mínima, é baixa. Sem deslocamento, é empate. O resultado usa só o que está visível nesse instante. O gráfico é uma simulação aleatória e não promete o próximo movimento."
	},
	{
		title: "Saldos",
		body: "Na vitória, a aposta volta e entra um prêmio adicional de 1 a 5 balas. O número anunciado é só o prêmio, não a devolução. Na derrota, perde-se apenas a quantidade apostada. No empate, a aposta volta e não há prêmio. O saldo não fica negativo e a mesma rodada não é liquidada duas vezes."
	},
	{
		title: "Prêmio em balas",
		body: "Cada vitória sorteia o prêmio com os pesos 28, 28, 22, 11 e 6 (soma 95), para 1, 2, 3, 4 e 5 balas. O sorteio não depende da altura da linha, do modo nem do valor apostado."
	},
	{
		title: "Pirulito raro",
		body: "É um brinde, não uma moeda. Não se aposta, não se compra e não substitui as balas. Só pode sair numa vitória, com 5% de chance independente do prêmio em balas. Derrota e empate nunca dão pirulito. Quando sai, a vitória continua visível junto com a animação do brinde."
	},
	{
		title: "Quadrinhos, SAIR e a rodada seguinte",
		body: "No fim da rodada, todos os quadrinhos aparecem ao mesmo tempo e permanecem até SAIR. SAIR depois da primeira ou da segunda rodada fecha o painel, devolve o gráfico à posição inicial e libera as apostas. A rodada seguinte não começa sozinha: é preciso clicar de novo em COMEÇAR RODADA. Depois da terceira, SAIR abre o ranking final e impede uma quarta rodada. O gráfico dessa última rodada fica congelado."
	},
	{
		title: "Estatísticas, TOP e reset",
		body: "A porcentagem de sucesso é vitórias ÷ (vitórias + derrotas) × 100. Empate não entra. Sem vitória e sem derrota, aparece um traço. O TOP usa os mesmos números e não desempatam porcentagens iguais. RESETAR TODOS OS DADOS pede confirmação em qualquer fase. Cancelar preserva tudo. Confirmar apaga a disputa e volta ao cadastro, sem apagar as imagens personalizadas."
	}
];
function HowToPage() {
	const art = useArt();
	const [message, setMessage] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-wide text-gold",
				children: "REGRAS"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: "Como jogar"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: SECTIONS.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "panel p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: section.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: section.body
					})]
				}, section.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel overflow-x-auto p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Tabela do prêmio adicional"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "mt-3 w-full min-w-[20rem] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Prêmio"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Peso"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: "Chance"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
							[
								"1 bala",
								"28",
								"29,47%"
							],
							[
								"2 balas",
								"28",
								"29,47%"
							],
							[
								"3 balas",
								"22",
								"23,16%"
							],
							[
								"4 balas",
								"11",
								"11,58%"
							],
							[
								"5 balas",
								"6",
								"6,32%"
							]
						].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
							className: "border-t border-line",
							children: row.map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-mono",
								children: cell
							}, cell))
						}, row[0])) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Exemplo de conta, não um resultado ao vivo: saldo 2, aposta 1, prêmio 3, saldo final 5. A aposta volta e as 3 balas são o prêmio."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel border-gold/40 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Aviso"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "A BalaBet usa somente balas virtuais, sem valor monetário, depósito ou saque. Apostar dinheiro real pode causar perdas financeiras e problemas pessoais ou familiares. Divirta-se com consciência. Não aposte dinheiro das necessidades essenciais e não tente recuperar perdas."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Aparência da bala e do pirulito"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "A troca muda só a imagem. Não altera saldo, chance ou regra."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: art.candy,
							alt: "Bala virtual",
							className: "size-16 rounded-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: art.lollipop,
							alt: "Pirulito raro",
							className: "size-16 rounded-full object-cover"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["Imagem da bala", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "file",
								accept: "image/*",
								onChange: async (event) => {
									const file = event.target.files?.[0] ?? null;
									setMessage(await art.setFile("candy", file));
								}
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm",
							children: ["Imagem do pirulito", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								type: "file",
								accept: "image/*",
								onChange: async (event) => {
									const file = event.target.files?.[0] ?? null;
									setMessage(await art.setFile("lollipop", file));
								}
							})]
						})]
					}),
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-loss",
						children: message
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost mt-3",
						onClick: () => art.resetArt(),
						children: "Restaurar imagens originais"
					})
				]
			})
		]
	});
}
//#endregion
export { HowToPage as component };
