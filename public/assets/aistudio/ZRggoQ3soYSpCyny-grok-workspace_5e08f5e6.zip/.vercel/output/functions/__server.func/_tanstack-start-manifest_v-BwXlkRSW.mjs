//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BwXlkRSW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/apostar",
			"/como-jogar",
			"/top",
			"/api/settle"
		],
		preloads: ["/assets/index-BAm9x6fU.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BAm9x6fU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-rODhFUvr.js"]
	},
	"/apostar": {
		filePath: "/workspace/src/routes/apostar.tsx",
		children: void 0,
		preloads: ["/assets/apostar-DGVhoVrX.js", "/assets/stats-table-BsIpoBMs.js"]
	},
	"/como-jogar": {
		filePath: "/workspace/src/routes/como-jogar.tsx",
		children: void 0,
		preloads: ["/assets/como-jogar-DXiYf6gE.js"]
	},
	"/top": {
		filePath: "/workspace/src/routes/top.tsx",
		children: void 0,
		preloads: ["/assets/top-C7U9h4b0.js", "/assets/stats-table-BsIpoBMs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
