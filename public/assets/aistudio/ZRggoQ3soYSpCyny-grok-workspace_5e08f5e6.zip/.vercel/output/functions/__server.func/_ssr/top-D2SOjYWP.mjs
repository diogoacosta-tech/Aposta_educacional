import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useDispute } from "./router-1gb8mQX7.mjs";
import { t as RankingTable } from "./stats-table-CG4FVpk8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/top-D2SOjYWP.js
var import_jsx_runtime = require_jsx_runtime();
function TopPage() {
	const final = useDispute((state) => state.phase) === "final";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-wide text-gold",
				children: "CLASSIFICAÇÃO"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: "TOP"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm leading-relaxed text-muted",
				children: "Ordenado pela porcentagem de sucesso. Quem tem a mesma porcentagem divide a posição — não há desempate por saldo, nome ou quantidade de vitórias."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankingTable, { final })]
	});
}
//#endregion
export { TopPage as component };
