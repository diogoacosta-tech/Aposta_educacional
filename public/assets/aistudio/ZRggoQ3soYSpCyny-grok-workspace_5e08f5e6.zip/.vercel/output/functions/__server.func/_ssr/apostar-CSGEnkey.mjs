import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as COUNTDOWN_MS, c as ROUND_MS, f as stakeError, i as useLive, l as formatBalas, m as useArt, n as phaseLabel, o as DIRECTION_LABEL, r as useDispute, s as MODE_LABEL } from "./router-1gb8mQX7.mjs";
import { n as StatsTable, t as RankingTable } from "./stats-table-CG4FVpk8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apostar-CSGEnkey.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TICKS = [
	100,
	80,
	50,
	30,
	10,
	0
];
function colorOf$1(index) {
	return `var(--color-player-${index + 1})`;
}
function toPoints(points) {
	return points.map((point) => {
		const x = point.t / ROUND_MS * 1e3;
		const y = 1e3 - point.y / 100 * 1e3;
		return `${x.toFixed(1)},${y.toFixed(1)}`;
	}).join(" ");
}
function ChartPanel({ phase }) {
	const liveChart = useLive((state) => state.chart);
	const snapshot = useDispute((state) => state.chartSnapshot);
	const players = useDispute((state) => state.players);
	const series = phase === "countdown" || phase === "running" ? liveChart : snapshot;
	const [hover, setHover] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel p-3 sm:p-4",
		"aria-label": "Gráfico da rodada",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold tracking-wide text-muted",
					children: "GRÁFICO"
				}), phase === "results" || phase === "final" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-gold",
					children: "CONGELADO"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-72 w-10 shrink-0 flex-col justify-between py-1 font-mono text-[10px] text-muted md:h-[26rem]",
					children: TICKS.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [tick, "%"] }, tick))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-72 min-w-0 flex-1 overflow-hidden rounded-xl border border-line bg-bg md:h-[26rem]",
					onMouseLeave: () => setHover(null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 1000 1000",
						className: "chart-grid h-full w-full",
						role: "img",
						"aria-label": "Linhas independentes dos jogadores",
						children: [
							TICKS.map((tick) => {
								const y = 1e3 - tick / 100 * 1e3;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "0",
									y1: y,
									x2: "1000",
									y2: y
								}, tick);
							}),
							[
								0,
								250,
								500,
								750,
								1e3
							].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: x,
								y1: "0",
								x2: x,
								y2: "1000"
							}, x)),
							players.map((player) => {
								const line = series?.find((item) => item.playerId === player.id);
								if (!line || line.points.length === 0) return null;
								const points = toPoints(line.points);
								const dim = hover !== null && hover !== player.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
									points,
									fill: "none",
									stroke: "transparent",
									strokeWidth: "36",
									onMouseEnter: () => setHover(player.id)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
									points,
									fill: "none",
									stroke: colorOf$1(player.colorIndex),
									strokeWidth: hover === player.id ? 7 : 4.5,
									strokeLinejoin: "miter",
									strokeLinecap: "butt",
									opacity: dim ? .28 : 1,
									style: { filter: hover === player.id ? "drop-shadow(0 0 6px currentColor)" : void 0 }
								})] }, player.id);
							})
						]
					}), !series ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pointer-events-none absolute inset-0 flex items-center justify-center px-6 text-center text-sm text-muted",
						children: "As linhas aparecem na contagem e se movem por 15 segundos."
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-wrap gap-2",
				children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "inline-flex items-center gap-2 rounded-full border border-line px-3 py-1 text-sm",
					style: { opacity: hover && hover !== player.id ? .45 : 1 },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2.5 rounded-full",
						style: { background: colorOf$1(player.colorIndex) }
					}), player.name]
				}, player.id))
			})
		]
	});
}
function tone(outcome) {
	if (outcome === "win") return "text-win";
	if (outcome === "loss") return "text-loss";
	return "text-gold";
}
function LossMarks({ count, src }) {
	if (count <= 36) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 flex max-h-28 flex-wrap gap-1 overflow-hidden",
		"aria-hidden": "true",
		children: Array.from({ length: count }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "bala-rise size-7 rounded-full object-cover"
		}, index))
	});
	const shown = Math.min(count, 4e3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 grid max-h-36 gap-0.5 overflow-hidden",
		style: { gridTemplateColumns: `repeat(${Math.min(Math.ceil(Math.sqrt(shown)), 24)}, minmax(0, 1fr))` },
		"aria-hidden": "true",
		children: Array.from({ length: shown }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "",
			className: "bala-rise aspect-square w-full rounded-full object-cover"
		}, index))
	});
}
function Card({ card, candy, lollipop }) {
	const headline = card.outcome === "win" ? "VOCÊ GANHOU!" : card.outcome === "loss" ? "VOCÊ PERDEU!" : "EMPATE!";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: `panel flex flex-col p-4 ${card.lollipop ? "lolli-glow" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: card.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-muted",
					children: MODE_LABEL[card.mode]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `count-pop mt-3 text-2xl font-semibold ${tone(card.outcome)}`,
				children: headline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Último segmento ",
					DIRECTION_LABEL[card.direction],
					"."
				]
			}),
			card.outcome === "win" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-lg text-win",
					children: [
						"+",
						formatBalas(card.prize),
						" balas de prêmio"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex gap-1",
					"aria-hidden": "true",
					children: Array.from({ length: card.prize }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: candy,
						alt: "",
						className: "bala-pop size-8 rounded-full object-cover"
					}, index))
				}),
				card.lollipop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: lollipop,
						alt: "",
						className: "bala-pop size-14 rounded-full object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-gold",
						children: "Pirulito raro"
					})]
				}) : null
			] }) : null,
			card.outcome === "loss" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-lg text-loss",
				children: [
					"−",
					formatBalas(card.stake),
					" balas"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LossMarks, {
				count: card.stake,
				src: candy
			})] }) : null,
			card.outcome === "tie" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-gold-2",
				children: [
					"A aposta de ",
					formatBalas(card.stake),
					" balas foi devolvida."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-auto pt-4 font-mono text-xs text-muted",
				children: ["Saldo: ", formatBalas(card.balanceAfter)]
			})
		]
	});
}
function ResultsPanel() {
	const roundView = useDispute((state) => state.roundView);
	const phase = useDispute((state) => state.phase);
	const exitResults = useDispute((state) => state.exitResults);
	const requestReset = useDispute((state) => state.requestReset);
	const { candy, lollipop } = useArt();
	const exitRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		exitRef.current?.focus();
	}, [roundView?.round]);
	if (phase !== "results" || !roundView) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 top-16 z-30 overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "results-title",
			className: "mx-auto w-full max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					id: "results-title",
					className: "text-xl font-semibold",
					children: [
						"Resultados da rodada ",
						roundView.round,
						"/3"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Os quadrinhos ficam aqui até você clicar em SAIR."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: requestReset,
						children: "Resetar todos os dados"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						"data-testid": "exit-results",
						ref: exitRef,
						onClick: exitResults,
						children: "SAIR"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
				children: roundView.cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					card,
					candy,
					lollipop
				}, card.playerId))
			})]
		})
	});
}
var MODES = [
	"subir",
	"cair",
	"automatico"
];
function colorOf(index) {
	return `var(--color-player-${index + 1})`;
}
function ApostarPage() {
	const phase = useDispute((state) => state.phase);
	const players = useDispute((state) => state.players);
	const roundIndex = useDispute((state) => state.roundIndex);
	const drafts = useDispute((state) => state.drafts);
	const locked = useDispute((state) => state.locked);
	const lockedBets = useDispute((state) => state.lockedBets);
	const banner = useDispute((state) => state.banner);
	const addPlayer = useDispute((state) => state.addPlayer);
	const removePlayer = useDispute((state) => state.removePlayer);
	const beginDispute = useDispute((state) => state.beginDispute);
	const setDraft = useDispute((state) => state.setDraft);
	const startRound = useDispute((state) => state.startRound);
	const [name, setName] = (0, import_react.useState)("");
	const [balance, setBalance] = (0, import_react.useState)("");
	const [formError, setFormError] = (0, import_react.useState)(null);
	const clock = useLive((state) => state.clockMs);
	const countdown = phase === "countdown" ? Math.max(1, 3 - Math.floor(clock / 1e3)) : null;
	const runningLeft = phase === "running" ? Math.max(0, ROUND_MS - Math.max(0, clock - COUNTDOWN_MS)) / 1e3 : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-wide text-gold",
					children: phaseLabel(phase, roundIndex)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-semibold tracking-tight",
					children: "Apostar"
				})] }), runningLeft !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-2xl text-fg",
					"aria-live": "polite",
					children: [runningLeft.toLocaleString("pt-BR", {
						minimumFractionDigits: 1,
						maximumFractionDigits: 1
					}), "s"]
				}) : null]
			}),
			banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "rounded-xl border border-loss/40 bg-surface px-4 py-3 text-sm text-loss",
				children: banner
			}) : null,
			phase === "registration" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "panel space-y-4 p-5",
					onSubmit: (event) => {
						event.preventDefault();
						const error = addPlayer(name, balance);
						if (error) {
							setFormError(error);
							return;
						}
						setFormError(null);
						setName("");
						setBalance("");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Cadastro"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "Até cinco jogadores, cada um com o próprio saldo em balas virtuais. Depois que a disputa começa, só um reset permite trocar a lista."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								value: name,
								onChange: (event) => setName(event.target.value),
								maxLength: 24,
								"aria-invalid": Boolean(formError)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm",
							children: ["Saldo inicial", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								inputMode: "numeric",
								value: balance,
								onChange: (event) => setBalance(event.target.value),
								placeholder: "Inteiro, mínimo 1"
							})]
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-loss",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "btn btn-primary",
							"data-testid": "add-player",
							disabled: players.length >= 5,
							children: "Adicionar jogador"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Jogadores"
						}),
						players.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Ninguém cadastrado ainda."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2",
							children: players.map((player) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 rounded-xl border border-line px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-2.5 rounded-full",
											style: { background: colorOf(player.colorIndex) }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: player.name }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-xs text-muted",
											children: [formatBalas(player.balance), " balas"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost",
									onClick: () => removePlayer(player.id),
									children: "Remover"
								})]
							}, player.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary mt-4",
							"data-testid": "begin-dispute",
							onClick: () => {
								const error = beginDispute();
								setFormError(error);
							},
							children: "Ir para as apostas"
						})
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2 xl:grid-cols-3",
					children: players.map((player) => {
						const draft = drafts[player.id] ?? {
							mode: "",
							amount: ""
						};
						const bet = lockedBets[player.id];
						const shownStake = locked && bet ? bet.stake : Number(draft.amount);
						const reserved = locked && bet ? Math.max(0, player.balance - bet.stake) : player.balance;
						const error = phase === "preparing" ? player.balance < 1 ? "Sem balas para a aposta mínima de 1. A rodada não pode começar." : !draft.mode ? "Escolha o modo." : stakeError(draft.amount, player.balance) : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "panel p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "flex items-center gap-2 font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-2.5 rounded-full",
											style: { background: colorOf(player.colorIndex) }
										}), player.name]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted",
										children: locked && bet ? `Disponível ${formatBalas(reserved)}` : `Saldo ${formatBalas(player.balance)}`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 grid grid-cols-3 gap-1",
									role: "group",
									"aria-label": `Modo de ${player.name}`,
									children: MODES.map((mode) => {
										const selected = (locked ? bet?.mode : draft.mode) === mode;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: locked || phase !== "preparing",
											"aria-pressed": selected,
											className: `btn ${selected ? "btn-primary" : "btn-ghost"} px-1 text-xs`,
											onClick: () => setDraft(player.id, { mode }),
											children: MODE_LABEL[mode]
										}, mode);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 block text-sm",
									children: ["Balas nesta rodada", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field mt-1 font-mono",
										inputMode: "numeric",
										disabled: locked || phase !== "preparing",
										value: locked && bet ? String(bet.stake) : draft.amount,
										onChange: (event) => setDraft(player.id, { amount: event.target.value })
									})]
								}),
								phase === "preparing" && error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-loss",
									children: error
								}) : null,
								locked && bet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted",
									children: [
										"Aposta bloqueada: ",
										formatBalas(shownStake),
										" · ",
										MODE_LABEL[bet.mode]
									]
								}) : null,
								player.history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: player.history.map((item) => {
										const word = item.outcome === "win" ? "vitória" : item.outcome === "loss" ? "derrota" : "empate";
										return `R${item.round} ${word}`;
									}).join(" · ")
								}) : null
							]
						}, player.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPanel, { phase }), countdown !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute inset-0 flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "count-pop font-mono text-7xl font-semibold text-gold",
							"aria-live": "assertive",
							children: countdown
						}, countdown)
					}) : null]
				}),
				phase === "running" && runningLeft !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 overflow-hidden rounded-full bg-surface-2",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-gold",
						style: { width: `${(ROUND_MS - runningLeft * 1e3) / ROUND_MS * 100}%` }
					})
				}) : null,
				phase === "preparing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-primary",
					"data-testid": "start-round",
					disabled: players.some((player) => {
						const draft = drafts[player.id];
						return player.balance < 1 || !draft || !draft.mode || stakeError(draft.amount, player.balance) !== null;
					}),
					onClick: () => startRound(),
					children: "COMEÇAR RODADA"
				}) : null,
				phase === "final" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "As três rodadas acabaram. O gráfico permanece no estado final e não existe quarta rodada."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankingTable, { final: true })]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsTable, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsPanel, {})
		]
	});
}
//#endregion
export { ApostarPage as component };
