import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-1gb8mQX7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var KEY = "balabet-art-v1";
function read() {
	if (typeof window === "undefined") return {
		candy: null,
		lollipop: null
	};
	try {
		const parsed = JSON.parse(localStorage.getItem(KEY) ?? "null");
		if (!parsed || typeof parsed !== "object") return {
			candy: null,
			lollipop: null
		};
		return {
			candy: typeof parsed.candy === "string" ? parsed.candy : null,
			lollipop: typeof parsed.lollipop === "string" ? parsed.lollipop : null
		};
	} catch {
		return {
			candy: null,
			lollipop: null
		};
	}
}
function useArt() {
	const [art, setArt] = (0, import_react.useState)({
		candy: null,
		lollipop: null
	});
	(0, import_react.useEffect)(() => {
		setArt(read());
	}, []);
	const candy = art.candy ?? "/assets/bala.jpg";
	const lollipop = art.lollipop ?? "/assets/pirulito.jpg";
	function save(next) {
		localStorage.setItem(KEY, JSON.stringify(next));
		setArt(next);
	}
	return {
		candy,
		lollipop,
		customized: Boolean(art.candy || art.lollipop),
		async setFile(kind, file) {
			if (!file) {
				save({
					...read(),
					[kind]: null
				});
				return null;
			}
			if (!file.type.startsWith("image/")) return "Envie um arquivo de imagem.";
			if (file.size > 7e5) return "Use uma imagem de até 700 KB.";
			const dataUrl = await file.arrayBuffer().then((buffer) => {
				const bytes = new Uint8Array(buffer);
				let binary = "";
				for (const byte of bytes) binary += String.fromCharCode(byte);
				return `data:${file.type};base64,${btoa(binary)}`;
			});
			save({
				...read(),
				[kind]: dataUrl
			});
			return null;
		},
		resetArt() {
			localStorage.removeItem(KEY);
			setArt({
				candy: null,
				lollipop: null
			});
		}
	};
}
var PRIZE_WEIGHTS = [
	28,
	28,
	22,
	11,
	6
];
var ROUND_MS = 15e3;
var COUNTDOWN_MS = 3e3;
var MODES = [
	"subir",
	"cair",
	"automatico"
];
function prizeFromRoll(roll) {
	if (!Number.isInteger(roll) || roll < 0 || roll >= 95) throw new Error("Rolagem de prêmio fora de 0..94.");
	let acc = 0;
	for (let i = 0; i < PRIZE_WEIGHTS.length; i++) {
		acc += PRIZE_WEIGHTS[i];
		if (roll < acc) return i + 1;
	}
	throw new Error("Tabela de prêmios inconsistente.");
}
function lollipopFromRoll(roll) {
	if (!Number.isInteger(roll) || roll < 0 || roll >= 100) throw new Error("Rolagem de pirulito fora de 0..99.");
	return roll < 5;
}
function outcomeOf(mode, direction) {
	if (direction === "flat") return "tie";
	if (mode === "subir") return direction === "up" ? "win" : "loss";
	if (mode === "cair") return direction === "down" ? "win" : "loss";
	return direction === "up" ? "win" : "loss";
}
function settle(input) {
	const { balance, stake, mode, direction, prizeRoll, lollipopRoll } = input;
	if (!Number.isSafeInteger(balance) || balance < 0) throw new Error("Saldo inválido.");
	if (!Number.isSafeInteger(stake) || stake < 1) throw new Error("A aposta mínima é 1 bala.");
	if (stake > balance) throw new Error("A aposta não pode passar do saldo disponível.");
	if (!MODES.includes(mode)) throw new Error("Modo inválido.");
	const outcome = outcomeOf(mode, direction);
	if (outcome === "loss") return {
		outcome,
		prize: 0,
		lollipop: false,
		balanceAfter: balance - stake,
		displayedDelta: -stake,
		stake,
		prizeRoll,
		lollipopRoll
	};
	if (outcome === "tie") return {
		outcome,
		prize: 0,
		lollipop: false,
		balanceAfter: balance,
		displayedDelta: 0,
		stake,
		prizeRoll,
		lollipopRoll
	};
	const prize = prizeFromRoll(prizeRoll);
	return {
		outcome,
		prize,
		lollipop: lollipopFromRoll(lollipopRoll),
		balanceAfter: balance + prize,
		displayedDelta: prize,
		stake,
		prizeRoll,
		lollipopRoll
	};
}
function randomRoll(span) {
	const buffer = /* @__PURE__ */ new Uint32Array(1);
	crypto.getRandomValues(buffer);
	return buffer[0] % span;
}
function settleLocal(input) {
	return settle({
		...input,
		prizeRoll: input.prizeRoll ?? randomRoll(95),
		lollipopRoll: input.lollipopRoll ?? randomRoll(100)
	});
}
function successRatio(wins, losses) {
	const decided = wins + losses;
	if (decided <= 0) return null;
	return wins / decided * 100;
}
function formatPercent(value) {
	if (value === null) return "—";
	return `${new Intl.NumberFormat("pt-BR", {
		minimumFractionDigits: 0,
		maximumFractionDigits: 1
	}).format(value)}%`;
}
function formatBalas(value) {
	return new Intl.NumberFormat("pt-BR").format(value);
}
function normalizeName(name) {
	return name.trim().replace(/\s+/g, " ");
}
function nameKey(name) {
	return normalizeName(name).toLocaleLowerCase("pt-BR");
}
function validateNewPlayer(name, balanceRaw, existingNames, existingCount) {
	if (existingCount >= 5) return { error: "O limite é de cinco jogadores por disputa." };
	const clean = normalizeName(name);
	if (!clean) return { error: "Informe um nome." };
	if (clean.length > 24) return { error: "Use um nome de até 24 caracteres." };
	const key = nameKey(clean);
	if (existingNames.some((item) => nameKey(item) === key)) return { error: "Esse nome já está na disputa." };
	const balance = parsePositiveInt(balanceRaw);
	if (balance === null || balance < 1) return { error: "O saldo inicial precisa ser um inteiro de pelo menos 1 bala." };
	return {
		name: clean,
		balance
	};
}
function parsePositiveInt(raw) {
	const text = raw.trim();
	if (!/^[0-9]+$/.test(text)) return null;
	const value = Number(text);
	if (!Number.isSafeInteger(value)) return null;
	return value;
}
function stakeError(raw, balance) {
	const text = raw.trim();
	if (!text) return "Informe quantas balas apostar.";
	if (!/^[0-9]+$/.test(text)) return "Use somente um número inteiro, sem decimais.";
	const value = Number(text);
	if (!Number.isSafeInteger(value) || value < 1) return "A aposta mínima é 1 bala.";
	if (value > balance) return `Saldo insuficiente. O máximo é ${formatBalas(balance)}.`;
	return null;
}
function rankPlayers(players) {
	const ordered = players.map((player, index) => ({
		...player,
		percent: successRatio(player.wins, player.losses),
		index
	}));
	ordered.sort((a, b) => {
		if (a.percent === null && b.percent === null) return a.index - b.index;
		if (a.percent === null) return 1;
		if (b.percent === null) return -1;
		if (a.percent !== b.percent) return b.percent - a.percent;
		return a.index - b.index;
	});
	return ordered.map((player, index) => {
		let rank = index + 1;
		if (index > 0) {
			const prev = ordered[index - 1];
			if (prev.percent === player.percent || prev.percent === null && player.percent === null) rank = findRank(ordered, index);
		}
		const next = ordered[index + 1];
		const tied = index > 0 && ordered[index - 1].percent === player.percent || next !== void 0 && next.percent === player.percent;
		return {
			id: player.id,
			name: player.name,
			wins: player.wins,
			losses: player.losses,
			percent: player.percent,
			rank,
			tied
		};
	});
}
function findRank(ordered, index) {
	const percent = ordered[index].percent;
	let cursor = index;
	while (cursor > 0 && ordered[cursor - 1].percent === percent) cursor -= 1;
	return cursor + 1;
}
function directionOf(points) {
	if (points.length < 2) return "flat";
	const previous = points[points.length - 2].y;
	const last = points[points.length - 1].y;
	if (last > previous) return "up";
	if (last < previous) return "down";
	return "flat";
}
var MODE_LABEL = {
	subir: "SUBIR",
	cair: "CAIR",
	automatico: "AUTOMÁTICO"
};
var DIRECTION_LABEL = {
	up: "subiu",
	down: "caiu",
	flat: "não se moveu"
};
function settleUrl() {
	const path = "/api/settle";
	if (typeof window === "undefined") return path;
	return `${previewPathPrefix(window.location.hostname, window.location.pathname) ?? ""}${path}`;
}
var useLive = create((set) => ({
	clockMs: 0,
	chart: null,
	setFrame: (clockMs, chart) => set({
		clockMs,
		chart
	}),
	clear: () => set({
		clockMs: 0,
		chart: null
	})
}));
function blankState() {
	return {
		epoch: 0,
		phase: "registration",
		roundIndex: 0,
		players: [],
		drafts: {},
		locked: false,
		lockedBets: {},
		activeRoundId: null,
		settledApplied: null,
		chartSnapshot: null,
		roundView: null,
		banner: null,
		resetOpen: false
	};
}
var settleLock = null;
function freshDrafts(players, previous) {
	const drafts = {};
	for (const player of players) {
		const prior = previous?.[player.id];
		const amount = prior && player.balance >= 1 ? String(Math.min(prior.stake, player.balance)) : "";
		drafts[player.id] = {
			mode: prior?.mode ?? "",
			amount: player.balance >= 1 ? amount : ""
		};
	}
	return drafts;
}
var useDispute = create()(persist((set, get) => ({
	...blankState(),
	clearBanner: () => set({ banner: null }),
	addPlayer: (name, balanceRaw) => {
		const state = get();
		if (state.phase !== "registration") return "Os jogadores não podem mudar depois que a disputa começa.";
		const result = validateNewPlayer(name, balanceRaw, state.players.map((player) => player.name), state.players.length);
		if ("error" in result) return result.error;
		const player = {
			id: crypto.randomUUID().replace(/-/g, "").slice(0, 16),
			name: result.name,
			colorIndex: state.players.length,
			initialBalance: result.balance,
			balance: result.balance,
			wins: 0,
			losses: 0,
			ties: 0,
			history: []
		};
		set({
			players: [...state.players, player],
			banner: null
		});
		return null;
	},
	removePlayer: (id) => {
		const state = get();
		if (state.phase !== "registration") return;
		set({ players: state.players.filter((player) => player.id !== id).map((player, index) => ({
			...player,
			colorIndex: index
		})) });
	},
	beginDispute: () => {
		const state = get();
		if (state.phase !== "registration") return "A disputa já começou.";
		if (state.players.length < 1) return "Cadastre pelo menos um jogador.";
		set({
			phase: "preparing",
			roundIndex: 0,
			drafts: freshDrafts(state.players),
			lockedBets: {},
			banner: null,
			chartSnapshot: null,
			roundView: null
		});
		useLive.getState().clear();
		return null;
	},
	setDraft: (id, patch) => {
		const state = get();
		if (state.phase !== "preparing" || state.locked) return;
		const current = state.drafts[id] ?? {
			mode: "",
			amount: ""
		};
		set({
			drafts: {
				...state.drafts,
				[id]: {
					...current,
					...patch
				}
			},
			banner: null
		});
	},
	startRound: () => {
		const state = get();
		const reject = (message) => {
			set({ banner: message });
			return message;
		};
		if (state.phase !== "preparing") return reject("A rodada não está em preparação.");
		if (state.roundIndex > 2) return reject("A disputa já teve as três rodadas.");
		const lockedBets = {};
		for (const player of state.players) {
			const draft = state.drafts[player.id];
			if (!draft || draft.mode !== "subir" && draft.mode !== "cair" && draft.mode !== "automatico") return reject(`${player.name} ainda precisa escolher SUBIR, CAIR ou AUTOMÁTICO.`);
			const text = draft.amount.trim();
			if (!/^[0-9]+$/.test(text)) return reject(`${player.name}: informe um inteiro de balas.`);
			const stake = Number(text);
			if (!Number.isSafeInteger(stake) || stake < 1) return reject(`${player.name}: a aposta mínima é 1 bala.`);
			if (stake > player.balance) return reject(`${player.name} não tem saldo para essa aposta.`);
			lockedBets[player.id] = {
				mode: draft.mode,
				stake
			};
		}
		useLive.getState().clear();
		set({
			phase: "countdown",
			locked: true,
			lockedBets,
			activeRoundId: crypto.randomUUID().replace(/-/g, "").slice(0, 16),
			settledApplied: null,
			chartSnapshot: null,
			roundView: null,
			banner: null
		});
		return null;
	},
	markRunning: () => {
		if (get().phase === "countdown") set({ phase: "running" });
	},
	settleRound: async (directions, chart) => {
		const state = get();
		const roundId = state.activeRoundId;
		if (!roundId) return;
		if (state.phase !== "running" && state.phase !== "countdown") return;
		if (state.settledApplied === roundId || settleLock === roundId) return;
		settleLock = roundId;
		const epoch = state.epoch;
		const roundNumber = state.roundIndex + 1;
		const payload = {
			roundId,
			players: state.players.map((player) => {
				const bet = state.lockedBets[player.id];
				const direction = directions.find((item) => item.playerId === player.id)?.direction ?? "flat";
				return {
					id: player.id,
					balance: player.balance,
					stake: bet.stake,
					mode: bet.mode,
					direction
				};
			})
		};
		let rows = null;
		try {
			const body = await (await fetch(settleUrl(), {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify(payload)
			})).json();
			if (body.ok && body.results) rows = body.results;
			else if (body.code === "validation") {
				if (get().epoch === epoch && get().activeRoundId === roundId) {
					set({
						phase: "preparing",
						locked: false,
						activeRoundId: null,
						banner: body.error ?? "A rodada foi recusada."
					});
					useLive.getState().clear();
				}
				settleLock = null;
				return;
			}
		} catch {
			rows = null;
		}
		const current = get();
		if (current.epoch !== epoch || current.activeRoundId !== roundId) {
			settleLock = null;
			return;
		}
		if (current.settledApplied === roundId) {
			settleLock = null;
			return;
		}
		const byId = new Map(rows?.map((row) => [row.id, row]) ?? []);
		const cards = [];
		const players = current.players.map((player) => {
			const bet = current.lockedBets[player.id];
			const direction = directions.find((item) => item.playerId === player.id)?.direction ?? "flat";
			const remote = byId.get(player.id);
			let settled;
			try {
				if (remote && (remote.outcome === "win" || remote.outcome === "loss" || remote.outcome === "tie")) {
					const checked = settle({
						balance: player.balance,
						stake: bet.stake,
						mode: bet.mode,
						direction,
						prizeRoll: remote.prizeRoll,
						lollipopRoll: remote.lollipopRoll
					});
					settled = checked.outcome === remote.outcome && checked.prize === remote.prize && checked.lollipop === remote.lollipop && checked.balanceAfter === remote.balanceAfter ? checked : settleLocal({
						balance: player.balance,
						stake: bet.stake,
						mode: bet.mode,
						direction
					});
				} else settled = settleLocal({
					balance: player.balance,
					stake: bet.stake,
					mode: bet.mode,
					direction
				});
			} catch {
				settled = settleLocal({
					balance: player.balance,
					stake: bet.stake,
					mode: bet.mode,
					direction
				});
			}
			const next = {
				...player,
				balance: settled.balanceAfter,
				wins: player.wins + (settled.outcome === "win" ? 1 : 0),
				losses: player.losses + (settled.outcome === "loss" ? 1 : 0),
				ties: player.ties + (settled.outcome === "tie" ? 1 : 0),
				history: [...player.history, {
					round: roundNumber,
					mode: bet.mode,
					stake: bet.stake,
					direction,
					outcome: settled.outcome,
					prize: settled.prize,
					lollipop: settled.lollipop,
					balanceAfter: settled.balanceAfter
				}]
			};
			cards.push({
				playerId: player.id,
				name: player.name,
				colorIndex: player.colorIndex,
				mode: bet.mode,
				direction,
				outcome: settled.outcome,
				stake: bet.stake,
				prize: settled.prize,
				lollipop: settled.lollipop,
				displayedDelta: settled.displayedDelta,
				balanceAfter: settled.balanceAfter
			});
			return next;
		});
		if (get().epoch !== epoch || get().activeRoundId !== roundId || get().settledApplied === roundId) {
			settleLock = null;
			return;
		}
		set({
			players,
			phase: "results",
			settledApplied: roundId,
			chartSnapshot: chart,
			roundView: {
				round: roundNumber,
				cards
			},
			locked: true
		});
		settleLock = null;
	},
	exitResults: () => {
		const state = get();
		if (state.phase !== "results") return;
		if (state.roundIndex >= 2) {
			set({
				phase: "final",
				locked: true,
				roundView: null
			});
			return;
		}
		set({
			phase: "preparing",
			roundIndex: state.roundIndex + 1,
			locked: false,
			drafts: freshDrafts(state.players, state.lockedBets),
			activeRoundId: null,
			roundView: null,
			chartSnapshot: null,
			banner: null
		});
		useLive.getState().clear();
	},
	requestReset: () => set({ resetOpen: true }),
	cancelReset: () => set({ resetOpen: false }),
	confirmReset: () => {
		settleLock = null;
		useLive.getState().clear();
		set({
			...blankState(),
			epoch: get().epoch + 1,
			resetOpen: false
		});
	}
}), {
	name: "balabet-dispute-v1",
	skipHydration: true,
	partialize: (state) => ({
		epoch: state.epoch,
		phase: state.phase,
		roundIndex: state.roundIndex,
		players: state.players,
		drafts: state.drafts,
		locked: state.locked,
		lockedBets: state.lockedBets,
		activeRoundId: state.activeRoundId,
		settledApplied: state.settledApplied,
		chartSnapshot: state.chartSnapshot,
		roundView: state.roundView,
		banner: state.banner
	}),
	onRehydrateStorage: () => (state) => {
		if (!state) return;
		if (state.phase === "countdown" || state.phase === "running") {
			useDispute.setState({
				phase: "preparing",
				locked: false,
				activeRoundId: null,
				chartSnapshot: null,
				roundView: null
			});
			useLive.getState().clear();
		}
	}
}));
function phaseLabel(phase, roundIndex) {
	const n = Math.min(roundIndex + 1, 3);
	switch (phase) {
		case "registration": return "CADASTRO";
		case "preparing": return `PREPARANDO RODADA ${n}/3`;
		case "countdown": return `RODADA ${n}/3 — CONTAGEM`;
		case "running": return `RODADA ${n}/3 EM ANDAMENTO`;
		case "results": return `RESULTADOS DA RODADA ${n}/3`;
		case "final": return "DISPUTA FINALIZADA";
	}
}
function nextY(rand, y) {
	if (rand() < .1) return y;
	const magnitude = rand() < .33 ? 12 + Math.floor(rand() * 30) : 1 + Math.floor(rand() * 8);
	const next = y + (rand() < .52 ? -1 : 1) * magnitude;
	if (next < 0) return 0;
	if (next > 100) return 100;
	return next;
}
function planSegment(rand, t, y) {
	if (t >= 15e3) return null;
	let duration = 240 + Math.floor(rand() * 280);
	if (t + duration > 15e3) duration = ROUND_MS - t;
	if (duration <= 0) return null;
	return {
		t0: t,
		t1: t + duration,
		y0: y,
		y1: nextY(rand, y)
	};
}
/**
* Gerador monotônico: visible(t) só pode ser chamado com t crescente.
* O próximo vértice só é fixado quando o instante dele chega, e o
* resultado usa os pontos visíveis — nunca um segmento além do relógio.
*/
function createLiveSimulator(rand, startY) {
	let cursorT = 0;
	let cursorY = startY ?? 20 + Math.floor(rand() * 61);
	const points = [{
		t: 0,
		y: cursorY
	}];
	let planned = planSegment(rand, cursorT, cursorY);
	return { visible(elapsed) {
		const e = Math.max(0, Math.min(ROUND_MS, elapsed));
		while (planned && planned.t1 <= e) {
			points.push({
				t: planned.t1,
				y: planned.y1
			});
			cursorT = planned.t1;
			cursorY = planned.y1;
			planned = planSegment(rand, cursorT, cursorY);
		}
		const visible = points.filter((point) => point.t <= e).map((point) => ({ ...point }));
		if (planned && e > planned.t0 && e < planned.t1) {
			const progress = (e - planned.t0) / (planned.t1 - planned.t0);
			visible.push({
				t: e,
				y: Math.round(planned.y0 + (planned.y1 - planned.y0) * progress)
			});
		}
		return visible;
	} };
}
function RoundDirector() {
	const roundId = useDispute((state) => state.activeRoundId);
	const epoch = useDispute((state) => state.epoch);
	(0, import_react.useEffect)(() => {
		const snap = useDispute.getState();
		if (snap.phase !== "countdown" || snap.activeRoundId !== roundId || !roundId) return;
		const ids = snap.players.map((player) => player.id);
		const sims = ids.map(() => createLiveSimulator(Math.random));
		const started = performance.now();
		let frame = 0;
		let settled = false;
		const loop = (now) => {
			const live = useDispute.getState();
			if (live.epoch !== epoch || live.activeRoundId !== roundId) return;
			const elapsed = now - started;
			if (elapsed < 3e3) {
				const series = ids.map((playerId, index) => ({
					playerId,
					points: sims[index].visible(0)
				}));
				useLive.getState().setFrame(elapsed, series);
			} else {
				live.markRunning();
				const run = Math.min(elapsed - COUNTDOWN_MS, ROUND_MS);
				const series = ids.map((playerId, index) => ({
					playerId,
					points: sims[index].visible(run)
				}));
				useLive.getState().setFrame(elapsed, series);
				if (elapsed - 3e3 >= 15e3 && !settled) {
					settled = true;
					const directions = series.map((item) => ({
						playerId: item.playerId,
						direction: directionOf(item.points)
					}));
					live.settleRound(directions, series);
					return;
				}
			}
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(frame);
	}, [roundId, epoch]);
	return null;
}
var LINKS = [
	{
		to: "/",
		label: "Início"
	},
	{
		to: "/apostar",
		label: "Apostar"
	},
	{
		to: "/top",
		label: "TOP"
	},
	{
		to: "/como-jogar",
		label: "Como jogar"
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const phase = useDispute((state) => state.phase);
	const roundIndex = useDispute((state) => state.roundIndex);
	const resetOpen = useDispute((state) => state.resetOpen);
	const requestReset = useDispute((state) => state.requestReset);
	const cancelReset = useDispute((state) => state.cancelReset);
	const confirmReset = useDispute((state) => state.confirmReset);
	const { candy } = useArt();
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const pending = useDispute.persist.rehydrate();
		if (pending instanceof Promise) {
			pending.then(() => setReady(true));
			return;
		}
		setReady(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundDirector, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "mr-1 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: candy || "/assets/bala.jpg",
								alt: "",
								className: "size-9 rounded-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg font-semibold tracking-tight",
								children: "BalaBet"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-1 gap-1 overflow-x-auto",
							"aria-label": "Principal",
							children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: link.to,
								className: "nav-link",
								"data-active": pathname === link.to,
								children: link.label
							}, link.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden font-mono text-xs tracking-wide text-gold sm:block",
							"aria-live": "polite",
							children: ready ? phaseLabel(phase, roundIndex) : "CARREGANDO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-danger",
							"data-testid": "reset-open",
							onClick: requestReset,
							children: "Resetar todos os dados"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-6xl px-4 py-6",
				children: ready ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Carregando a disputa…"
				})
			}),
			resetOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
				role: "presentation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "reset-title",
					className: "panel w-full max-w-md p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "reset-title",
							className: "text-lg font-semibold",
							children: "Apagar a disputa?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: "Todos os dados desta disputa serão apagados: jogadores, saldos, apostas, vitórias, derrotas, empates, ranking, histórico, gráfico e sorteios. As imagens personalizadas permanecem."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: cancelReset,
								children: "Cancelar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-danger",
								"data-testid": "reset-confirm",
								onClick: confirmReset,
								children: "Apagar disputa"
							})]
						})
					]
				})
			}) : null
		]
	});
}
var styles_default = "/assets/styles-BwBx8j3W.css";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "BalaBet" },
			{
				name: "theme-color",
				content: "#070b12"
			},
			{
				name: "description",
				content: "Simulação de apostas com balas virtuais, três rodadas e gráfico ao vivo."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Outfit:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$3 = () => import("./routes-KIjWDHjp.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./apostar-CSGEnkey.mjs");
var Route$3 = createFileRoute("/apostar")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./como-jogar-B5vodlDf.mjs");
var Route$2 = createFileRoute("/como-jogar")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./top-D2SOjYWP.mjs");
var Route$1 = createFileRoute("/top")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route = createFileRoute("/api/settle")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({
			ok: false,
			code: "validation",
			error: "JSON inválido."
		}, { status: 400 });
	}
	const { settleThroughSchoolStack } = await import("./school-bridge.server-lYBOq4Uk.mjs");
	const result = await settleThroughSchoolStack(body);
	return Response.json(result.json, { status: result.status });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	ApostarRoute: Route$3.update({
		id: "/apostar",
		path: "/apostar",
		getParentRoute: () => Route$5
	}),
	ComoJogarRoute: Route$2.update({
		id: "/como-jogar",
		path: "/como-jogar",
		getParentRoute: () => Route$5
	}),
	TopRoute: Route$1.update({
		id: "/top",
		path: "/top",
		getParentRoute: () => Route$5
	}),
	ApiSettleRoute: Route.update({
		id: "/api/settle",
		path: "/api/settle",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { COUNTDOWN_MS as a, ROUND_MS as c, rankPlayers as d, stakeError as f, useLive as i, formatBalas as l, useArt as m, phaseLabel as n, DIRECTION_LABEL as o, successRatio as p, useDispute as r, MODE_LABEL as s, router_exports as t, formatPercent as u };
